# 9) pattern
n=int(input("Enter the number: "))
print()
for i in range(1,n+1):
    for j in range(0,i):
        print('* ',end='')
    print('\n',end='')
print('\n',end='')
for i in range(n,0,-1):
    for j in range(0,i):
        print('* ',end='')
    print('\n',end='')