# 8) pattern
n=int(input("Enter the number: "))
print()
for i in range(0,n):
    for j in range(1,n+1):
        if(j==n):
            print(j,end='')
        else:
            print('{}*'.format(j),end='')
    n=n-1
    print('\n',end='')