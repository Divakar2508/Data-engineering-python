# 1) to compute the frequency of the words 
s=input("Enter the input: ").split()
res={}
for i in sorted(s):
    res[i]=res.get(i,0)+1

print()
for i in res.keys():
    print('{}:{}'.format(i,res[i]))
