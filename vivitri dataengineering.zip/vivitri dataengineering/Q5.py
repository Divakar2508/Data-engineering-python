# 5) . Convert a String to camelCase
s=input("Enter a string: ").split()
res=[]
for i in s:
    s1=list(i)
    if ord(i[0])>=65 and ord(i[0])<=90 :
        s1[0]=chr(ord(i[0])+32)
    else:
         s1[0]=chr(ord(i[0])-32)
    res.append(''.join(s1))
print(''.join(res))