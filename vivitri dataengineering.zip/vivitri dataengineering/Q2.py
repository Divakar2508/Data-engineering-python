# 2) Validating passwords
import re
test=input("Enter the input: ").split(',')
for i in test:
    if(len(i)>=6 and len(i)<=12):
        if re.search(r'[a-z]+',i) and re.search(r'[0-9]+',i) and re.search(r'[A-Z]+',i) and re.search(r'[$#@]+',i) :
            print()
            print(i)
