# 3) Write a program which takes 2 digits, X,Y as input and generates a 2-dimensional array
x=int(input("Enter the number: "))
y=int(input("Enter the number: "))
res=[]
for i in range(0,x):
    s=[]
    for j in range(0,y):
        s.append(i*j)
    res.append(s)
print(res)