# 6) Find uncommon words from two string
str1 = input("Enter string1: ").split()
str2 = input("Enter string2: ").split()
print(set(str1)^set(str2))
