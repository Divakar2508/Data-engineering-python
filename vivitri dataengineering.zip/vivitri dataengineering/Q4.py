# 4) find all words whose length is greater than k.
s=input("Enter the input: ").split()
res=[]
k=6
for i in s:
    if len(i)>6:
        res.append(i)
print(','.join(res))